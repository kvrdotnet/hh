﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using mvcSurveyExample.Models;

namespace mvcSurveyExample.Controllers
{
    public class HHolderController : Controller
    {
        private readonly AppDbContext _context;

        public HHolderController(AppDbContext context)
        {
            _context = context;
        }

        // GET: HHolder
        public async Task<IActionResult> Index()
        {
            return View(await _context.HouseHolder.ToListAsync());
        }
        //adding code manually for grouping data
        public IActionResult GroupDetails()
        {
            List<HouseHolder> hs = new List<HouseHolder>();
            var details = _context.HouseHolder.GroupBy(n => n.profession).Select(group =>
                     new
                     {
                         profession = group.Key,
                         Count = group.Count(),
                        
                     }).ToList();

            ViewBag.kkk = details.ToList();

            var status = _context.HouseHolder.GroupBy(x => x.profession).OrderByDescending(g => g.Count()).FirstOrDefault().Key;
            ViewBag.report = status;
            return View();
        }
    
            
        

        // GET: HHolder/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var houseHolder = await _context.HouseHolder
                .FirstOrDefaultAsync(m => m.Id == id);
            if (houseHolder == null)
            {
                return NotFound();
            }

            return View(houseHolder);
        }

        // GET: HHolder/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: HHolder/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,name,hno,profession")] HouseHolder houseHolder)
        {
            if (ModelState.IsValid)
            {
                _context.Add(houseHolder);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(houseHolder);
        }

        // GET: HHolder/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var houseHolder = await _context.HouseHolder.FindAsync(id);
            if (houseHolder == null)
            {
                return NotFound();
            }
            return View(houseHolder);
        }

        // POST: HHolder/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,name,hno,profession")] HouseHolder houseHolder)
        {
            if (id != houseHolder.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(houseHolder);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HouseHolderExists(houseHolder.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(houseHolder);
        }

        // GET: HHolder/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var houseHolder = await _context.HouseHolder
                .FirstOrDefaultAsync(m => m.Id == id);
            if (houseHolder == null)
            {
                return NotFound();
            }

            return View(houseHolder);
        }

        // POST: HHolder/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var houseHolder = await _context.HouseHolder.FindAsync(id);
            if (houseHolder != null)
            {
                _context.HouseHolder.Remove(houseHolder);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HouseHolderExists(int id)
        {
            return _context.HouseHolder.Any(e => e.Id == id);
        }
    }
}
