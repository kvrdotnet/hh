﻿namespace mvcSurveyExample.Models
{
    public class HHgroup
    {
        public string profession { get; set; }
        public int Count { get; set; }
    }
}
