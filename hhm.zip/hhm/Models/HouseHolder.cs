﻿namespace mvcSurveyExample.Models
{
    public class HouseHolder
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string hno { get; set; }
        public string profession { get; set; }
        public int Count { get; set; }
    }
}
